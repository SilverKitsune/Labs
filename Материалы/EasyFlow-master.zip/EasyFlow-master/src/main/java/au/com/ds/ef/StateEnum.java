package au.com.ds.ef;

/**
 * User: andrey
 * Date: 3/12/2013
 * Time: 9:52 PM
 */
public interface StateEnum {
    String name();
}
